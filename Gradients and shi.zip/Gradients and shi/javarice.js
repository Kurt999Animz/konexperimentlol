function start() {
    const bgmusic = document.getElementById('bgmusic');
       bgmusic.play()
    ;

    bgmusic.addEventListener("play", function() {
        const elements = document.querySelectorAll("*");
        elements.forEach((element) => {
            element.style.animationPlayState = "running,running";  // start them animatins
        });
    });
}

function mutesound() {
    const bgmusic = document.getElementById('bgmusic');
    bgmusic.muted = !bgmusic.muted;
}


document.querySelector('.soundbreh').addEventListener('click', function() {
    const button = this;
    if (button.style.backgroundImage == 'url("mute/muted.gif")') {
        button.style.backgroundImage = 'url("mute/unmuted.gif")';
    } else {
        button.style.backgroundImage = 'url("mute/muted.gif")';
    }
});
const elements = document.querySelectorAll('label, button');
elements.forEach(element => {
    element.addEventListener('click', clicksoundlol);
});


function clicksoundlol() {
    const interactionSound = new Audio('sounds/clicksound.mp3');
    interactionSound.play();
}


const row = document.querySelector('.maincont');
row.addEventListener('scroll', function() {
    const scrollLeft = row.scrollLeft;
    // Reverse the direction of the background movement by changing the sign
    row.style.backgroundPosition = `${-scrollLeft * 0.1}px center`; // Background moves horizontally
    });


const gifMap = {
  s1: "testgif.gif",  // Map box1 to testgif.gif
  s2: "", // Map box2 to testgif2.gif
  s3: "testgif2.gif",
  s4: "",
  s5: "train.gif",
  s6: "",
  s7: "testgif5.gif",
  s8: ""
};

// Select all boxes and GIFs
const boxes = document.querySelectorAll(".s1, .s2, .s3, .s4, .s5, .s6, .s7, .s8");
const gifs = document.querySelectorAll(".s1gif, .s2gif, .s3gif, .s4gif, .s5gif, .s6gif, .s7gif, .s8gif");

// Initially pause the GIFs by clearing their src attributes
gifs.forEach(gif => gif.src = ""); // Start in a paused state

// Add event listeners for each box
boxes.forEach(box => {
  box.addEventListener("animationstart", () => {
    playGif(box); // Pass the box to playGif
  });

  box.addEventListener("animationend", () => {
    pauseGif(box); // Pass the box to pauseGif
  });
});

// Custom function to play the GIF associated with a specific box
function playGif(box) {
  let gifClass, gifSrc;

  if (box.classList.contains("s1")) {
    gifClass = "s1gif";
    gifSrc = gifMap.s1;
  } else if (box.classList.contains("s2")) {
    gifClass = "s2gif";
    gifSrc = gifMap.s2;
  } else if (box.classList.contains("s3")) {
    gifClass = "s3gif";
    gifSrc = gifMap.s3;
  } else if (box.classList.contains("s4")) {
    gifClass = "s4gif";
    gifSrc = gifMap.s4;
  } else if (box.classList.contains("s5")) {
    gifClass = "s5gif";
    gifSrc = gifMap.s5;
  } else if (box.classList.contains("s6")) {
    gifClass = "s6gif";
    gifSrc = gifMap.s6;
  } else if (box.classList.contains("s7")) {
    gifClass = "s7gif";
    gifSrc = gifMap.s7;
  } else if (box.classList.contains("s8")) {
    gifClass = "s8gif";
    gifSrc = gifMap.s8;
  }
  const gif = document.querySelector(`.${gifClass}`);
  if (gif) gif.src = gifSrc; // Set the corresponding GIF's src
}

// Custom function to pause the GIF associated with a specific box
function pauseGif(box) {
  let gifClass;

  if (box.classList.contains("s1")) {
    gifClass = "s1gif";
  } else if (box.classList.contains("s2")) {
    gifClass = "s2gif";
  } else if (box.classList.contains("s3")) {
    gifClass = "s3gif";
  } else if (box.classList.contains("s4")) {
    gifClass = "s4gif";
  } else if (box.classList.contains("s5")) {
    gifClass = "s5gif";
  } else if (box.classList.contains("s6")) {
    gifClass = "s6gif";
  } else if (box.classList.contains("s7")) {
    gifClass = "s7gif";
  } else if (box.classList.contains("s8")) {
    gifClass = "s8gif";
  }

  const gif = document.querySelector(`.${gifClass}`);
  if (gif) gif.src = ""; // Clear the src to pause the GIF
}